@extends('layout.malay_layout.default')

@section('content')

<div class="page-content-inner">
    <section class="panel panel-with-borders">
        <div class="panel-heading">
            <h3>{{$title}}</h3>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <?php $active = 'active'; ?>
                        <?php foreach ($formtype as $ft) { ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo $active ?>" id="tab-{{ $ft->id }}" data-toggle="tab" href="#tab-pane{{ $ft->id }}" role="tab" aria-controls="{{ $ft->id }}" aria-selected="true">{{ $ft->name_my }}</a>
                            </li> 
                            <?php $active = ''; ?>
                        <?php } ?>
                    </ul>
                    <div class="tab-content padding-vertical-20" id="myTabContent">
                        <?php $active_show = 'show active in'; ?>
                        <?php foreach ($formtype as $ft) { ?>
                            <div class="tab-pane fade <?php echo $active_show ?>" id="tab-pane{{ $ft->id }}" role="tabpanel" aria-labelledby="tab-{{ $ft->id }}">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <table class="table table-bordered">
                                                <?php $formFile = AdminForm::where('form_type_id', $ft->id)->where('is_active', 1)->where('is_deleted', 0)->orderBy('sort_no')->get(); ?>
                                                <tbody>
                                                    <?php foreach ($formFile as $files) { ?>
                                                    <tr>
                                                        <td>
                                                            <a href="{{ asset($files->file_url) }}" target="_blank">{{ $files->name_my }}</a>
                                                        </td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div> 
                            </div>
                            <?php $active_show = ''; ?>
                        <?php } ?>
                    </div>                
                </div>
            </div>
        </div>
    </section>
</div>

@endsection