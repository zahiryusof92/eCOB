<table class="table table-bordered">
<tbody>
    <tr>
    <td class="detail-title">File No:</td>
    <td>{{ $fileNo }}</td>
    <td class="detail-title">COB File ID:</td>
    <td>{{ $fileId }}</td>
    </tr>
</tbody>
</table>