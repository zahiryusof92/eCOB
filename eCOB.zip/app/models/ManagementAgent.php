<?php

class ManagementAgent extends Eloquent {
    protected $table = 'management_agent';
}