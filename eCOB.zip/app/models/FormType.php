<?php

class FormType extends Eloquent {
    protected $table = 'form_type';
}