<?php

class FinanceCheck extends Eloquent {
    protected $table = 'finance_check';
}