<?php

class Agent extends Eloquent {
    protected $table = 'agent';
}