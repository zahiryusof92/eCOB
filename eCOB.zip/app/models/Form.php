<?php

class Form extends Eloquent {
    protected $table = 'form';
}