<?php

class FinanceReport extends Eloquent {
    protected $table = 'finance_file_report';
}

