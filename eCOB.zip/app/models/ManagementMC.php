<?php

class ManagementMC extends Eloquent {
    protected $table = 'management_mc';
}