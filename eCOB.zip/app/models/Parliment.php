<?php

class Parliment extends Eloquent {
    protected $table = 'parliment';
}