<?php

class AdminForm extends Eloquent {
    protected $table = 'form';
}