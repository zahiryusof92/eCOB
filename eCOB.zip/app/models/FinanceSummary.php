<?php

class FinanceSummary extends Eloquent {
    protected $table = 'finance_file_summary';
}