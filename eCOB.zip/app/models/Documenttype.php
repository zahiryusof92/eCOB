<?php

class Documenttype extends Eloquent {
    protected $table = 'document_type';
}