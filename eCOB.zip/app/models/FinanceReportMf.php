<?php

class FinanceReportMf extends Eloquent {
    protected $table = 'finance_file_report_mf';
}