<?php

class SubModule extends Eloquent {
    protected $table = 'sub_module';
}