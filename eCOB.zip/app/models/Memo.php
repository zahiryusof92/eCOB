<?php

class Memo extends Eloquent {
    protected $table = 'memo';
}