<?php

class Country extends Eloquent {
    protected $table = 'country';
}