<?php

class HouseScheme extends Eloquent {
    protected $table = 'house_scheme';
}