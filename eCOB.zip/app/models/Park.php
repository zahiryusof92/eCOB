<?php

class Park extends Eloquent {
    protected $table = 'park';
}