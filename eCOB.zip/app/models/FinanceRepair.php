<?php

class FinanceRepair extends Eloquent {
    protected $table = 'finance_file_repair';
}