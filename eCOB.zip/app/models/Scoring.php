<?php

class Scoring extends Eloquent {
    protected $table = 'scoring_quality_index';
}