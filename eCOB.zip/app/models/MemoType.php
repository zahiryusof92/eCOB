<?php

class MemoType extends Eloquent {
    protected $table = 'memo_type';
}