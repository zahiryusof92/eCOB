<?php

class LandTitle extends Eloquent {
    protected $table = 'land_title';
}