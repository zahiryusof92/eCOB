<?php

class MeetingDocument extends Eloquent {
    protected $table = 'meeting_document';
}