<?php

class AuditTrail extends Eloquent {
    protected $table = 'audit_trail';
}