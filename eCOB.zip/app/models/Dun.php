<?php

class Dun extends Eloquent {
    protected $table = 'dun';
}