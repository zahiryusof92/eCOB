<?php

class Buyer extends Eloquent {
    protected $table = 'buyer';
}