<?php

class Developer extends Eloquent {
    protected $table = 'developer';
}