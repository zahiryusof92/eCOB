<?php

class FinanceStaff extends Eloquent {
    protected $table = 'finance_file_staff';
}