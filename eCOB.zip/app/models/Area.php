<?php

class Area extends Eloquent {
    protected $table = 'area';
}