<?php

class Module extends Eloquent {
    protected $table = 'module';
}