<?php

class City extends Eloquent {
    protected $table = 'city';
}