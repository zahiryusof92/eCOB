<?php

class FinanceAdmin extends Eloquent {
    protected $table = 'finance_file_admin';
}