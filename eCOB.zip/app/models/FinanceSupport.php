<?php

class FinanceSupport extends Eloquent {
    protected $table = 'finance_support';
}