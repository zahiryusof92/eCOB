<?php

class FinanceVandal extends Eloquent {
    protected $table = 'finance_file_vandalisme';
}