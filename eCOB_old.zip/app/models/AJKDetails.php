<?php

class AJKDetails extends Eloquent {
    protected $table = 'ajk_details';
}