<?php

class FinanceReportPerbelanjaan extends Eloquent {
    protected $table = 'finance_file_report_perbelanjaan';
}