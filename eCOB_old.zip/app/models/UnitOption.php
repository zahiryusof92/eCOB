<?php

class UnitOption extends Eloquent {
    protected $table = 'unit_option';
}