<?php

class ManagementJMB extends Eloquent {
    protected $table = 'management_jmb';
}