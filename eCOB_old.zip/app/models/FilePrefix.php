<?php

class FilePrefix extends Eloquent {
    protected $table = 'fileprefix';
}