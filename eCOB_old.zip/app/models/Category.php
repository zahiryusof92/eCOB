<?php

class Category extends Eloquent {
    protected $table = 'category';
}