<?php

class Strata extends Eloquent {
    protected $table = 'strata';
}