<?php

class State extends Eloquent {
    protected $table = 'state';
}