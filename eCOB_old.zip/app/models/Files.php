<?php

class Files extends Eloquent {
    protected $table = 'files';
}