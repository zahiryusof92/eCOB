<?php

class AgmDesignSub extends Eloquent {
    protected $table = 'agm_design_sub';
}