<?php

class Residential extends Eloquent {
    protected $table = 'residential_block';
}