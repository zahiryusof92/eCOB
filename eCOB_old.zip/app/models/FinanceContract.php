<?php

class FinanceContract extends Eloquent {
    protected $table = 'finance_file_contract';
}