<?php

class OtherDetails extends Eloquent {
    protected $table = 'others_details';
}