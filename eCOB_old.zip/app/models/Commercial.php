<?php

class Commercial extends Eloquent {
    protected $table = 'commercial_block';
}