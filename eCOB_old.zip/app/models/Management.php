<?php

class Management extends Eloquent {
    protected $table = 'management';
}