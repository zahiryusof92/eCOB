<?php

class ManagementOthers extends Eloquent {
    protected $table = 'management_others';
}