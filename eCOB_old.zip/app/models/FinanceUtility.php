<?php

class FinanceUtility extends Eloquent {
    protected $table = 'finance_file_utility';
}