<?php

class Company extends Eloquent {
    protected $table = 'company';
}