<?php

class FinanceIncome extends Eloquent {
    protected $table = 'finance_file_income';
}