<?php

class Role extends Eloquent {
    protected $table = 'role';
}