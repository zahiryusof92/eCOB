<?php

class Facility extends Eloquent {
    protected $table = 'facility';
}